package com.cg.CpagStoreProject.dao;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.CpagStoreProject.model.Pilot;

@Repository("pilotDBdao")
@Transactional
public interface PilotDaoInterface extends JpaRepository<Pilot, Integer> {

	
}
