package com.cg.CpagStoreProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CpagStoreProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(CpagStoreProjectApplication.class, args);
	}
}
