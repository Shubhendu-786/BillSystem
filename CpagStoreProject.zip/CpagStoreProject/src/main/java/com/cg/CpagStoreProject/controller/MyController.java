package com.cg.CpagStoreProject.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.CpagStoreProject.model.Pilot;
import com.cg.CpagStoreProject.service.PilotServiceInterface;

@RestController
@RequestMapping("/api/v1")
public class MyController {
	
	@Autowired
	private PilotServiceInterface pilotDBService;
	
	/*@GetMapping("/pilots")
	public ResponseEntity<List<Pilot>> getAllPilots()
	{
		List<Pilot> pilots=pilotDBService.getAllPilots();
		if(pilots.isEmpty()||pilots==null)
		{
		  return new ResponseEntity("Sorry! Pilot details not available!",HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Pilot>>(pilots,HttpStatus.OK);
	}*/
	
	
	@GetMapping("/pilots")
	public ResponseEntity<List<Pilot>> getAllPilots(){
		System.out.println("I am in pilots");
		List<Pilot> pilots= pilotDBService.getAllPilots();
		if(pilots.isEmpty()||pilots==null)
			return new ResponseEntity
				("Sorry! Pilot details not available!",HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<Pilot>>(pilots,HttpStatus.OK);
	}
	
	@GetMapping("/pilot/{pilotId}")
	public ResponseEntity<Pilot> getPilot(@PathVariable("pilotId") Integer pilotId){
		System.out.println("i am in pilots pilotId");
		//Pilot pilot= 
				Pilot pilot=pilotDBService.findPilot(pilotId);
		System.out.println("Pilot in controller of rest"+pilot);
		//if(pilot==null)
			//return new ResponseEntity
				//("Sorry! Pilot details not available!",HttpStatus.NOT_FOUND);
		return new ResponseEntity<Pilot>(pilot,HttpStatus.OK);
			}
	

	@PostMapping("/pilots")
	public ResponseEntity<Pilot> createPilot(@RequestBody Pilot pilot){
		pilotDBService.save(pilot);
		
		return new ResponseEntity<Pilot>(pilot,HttpStatus.OK);
	}
	
	@DeleteMapping("/pilots/{pilotId}")
	public void deletePilot(@PathVariable("pilotId") Integer pilotId) {
		
		pilotDBService.deletePilot(pilotId);
		
	}
	
	
	/*@PutMapping("/pilots/{pilotId}")
	public void updatePilot(@PathVariable("pilotId") Integer pilotId)
	{
		pilotDBService.findPilot(pilotId);
	}
	*/
	
	
}
 


