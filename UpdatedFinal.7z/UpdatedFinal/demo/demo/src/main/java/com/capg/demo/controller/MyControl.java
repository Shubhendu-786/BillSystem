package com.capg.demo.controller;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capg.demo.model.Attraction;
import com.capg.demo.model.Customer;
import com.capg.demo.model.Email;
import com.capg.demo.service.PilotServiceInterface;




@RestController
@RequestMapping("/api/v3")
public class MyControl {

	@Autowired
	private PilotServiceInterface pilotDBService;
	
	
	@GetMapping("/maxId")
	public Integer getMaxId()
	{//System.out.println("id : controller");
	  int i=pilotDBService.getMaxId();
	  System.out.println("i is"+i);
	  
	  
		return i;
	}
	
	@PostMapping("/put1")
	public void putImage(@RequestBody Attraction product)
	{//System.out.println("Put : controller");
		pilotDBService.save(product);
	}
	
	@GetMapping("/getAll")
	public ResponseEntity<List<Attraction>> getAllImages(){
		//System.out.println("getall : controller");
		List<Attraction> products= pilotDBService.getAllProducts();
		if(products.isEmpty()||products==null)
			return new ResponseEntity
				("Sorry! Image details not available!",HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<Attraction>>(products,HttpStatus.OK);
	}
	@GetMapping("/getAllCustomer")
	public ResponseEntity<List<Customer>> getAllCustomer(){
		System.out.println("getall : customer");
		
		Date date=new Date();
		Calendar cal = Calendar.getInstance();
	    cal.setTime(date);
	    cal.add(Calendar.DATE, -10); //minus number would decrement the days
	    Date d3= cal.getTime();
		
		List<Customer> products= pilotDBService.getAllCustomer(d3);
		if(products.isEmpty()||products==null)
			return new ResponseEntity
				("Sorry! Customer details not available!",HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<Customer>>(products,HttpStatus.OK);
	}
	
	
	@GetMapping("/getAttractionById/{id}")
	public ResponseEntity<Attraction> getAttraction(@PathVariable("id") Integer id){
		Attraction attraction=pilotDBService.findAttraction(id);
		
		return new ResponseEntity<Attraction>(attraction,HttpStatus.OK);
		
			}
	
	@PostMapping("/sentMail")
	public void putMail()
	{
		Email email=new Email();
		
		
		List<Customer> products= pilotDBService.getAllCustomer(new Date());
		
		Attraction attraction=pilotDBService.findAttraction(1);
		
		email.setFrom_emailId("ad@gmail.com");
		email.setTo_emailId(products.get(0).getEmailId());
		email.setBody(attraction.getAttractionName()+attraction.getAttractionId());
		email.setSubject("attraction");
		email.setDate(new Date());
		
		
		System.out.println("Email : restcontroller");
		pilotDBService.saveMail(email);
	}
	
	
	
	
	
	
}
