package com.capg.demo.dao;

import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.jboss.logging.Param;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.capg.demo.model.Customer;

@Repository("customerDBdao")
@Transactional
public interface CustomerInterface extends JpaRepository<Customer,Integer>{
	@Query("select c from Customer c where c.dateOfBirth > ?1")
	public List<Customer> findByDate(Date date);
}
