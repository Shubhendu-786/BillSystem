package page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class LoginPageBean {
  WebDriver driver;
 /* private By userName=By.name("userName");
  private By userPwd=By.name("userPwd");
  private By pageHeading=By.xpath("//*[@id=\"footer\"]/div[1]/h1");
  private By subLogin=By.name("login");*/
  
  
  @FindBy(name="userName",how=How.NAME)
	private WebElement userName;
	
	@FindBy(name="userPwd")
	private WebElement userPass;
	
	@FindBy(name="login")
	private WebElement subLogin;
	
	@FindBy(xpath="//*[@id=\"footer\"]/div[1]/h1")
	private WebElement pageHeading;
  
  public LoginPageBean(WebDriver driver)
  {
	   this.driver=driver;
	   PageFactory.initElements(driver, this);
	  
  }
  
   public void setUserName(String usrName)
   {
	 //   driver.findElement(userName).sendKeys(usrName);
	   userName.sendKeys(usrName);
	    
   }
  
   public void setUserPwd(String usrPwd)
   {
	  //  driver.findElement(userPwd).sendKeys(usrPwd);
	   userPass.sendKeys(usrPwd);
   }
   public void setSubLogin() {
	//	driver.findElement(subLogin).submit();
		subLogin.submit();
	}
	
	public String getPageTitle() {
		//return driver.findElement(pageHeading).getText();
		return pageHeading.getText();
	}
	
	public void login_to_nextpage(String uName,String uPass) {
		this.setUserName(uName);
		this.setUserPwd(uPass);
		this.setSubLogin();
	}
  
}
