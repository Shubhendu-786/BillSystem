package login;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Stepdef {
	
	
	private WebDriver driver;
	private WebElement element;
	
	
	@Before
	public void set()
	{
		System.setProperty("webdriver.chrome.driver", "D:\\Driver\\chromedriver.exe");
		
//		if(driver==null)
			driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}
	
	
	
	
	
	@Given("^Open login page$")
	public void open_login_page() throws Throwable {
		driver.get("http://localhost:8084/WalletApp/");
	}

	@When("^Username and password valid$")
	public void username_and_password_valid() throws Throwable {
		 element=driver.findElement(By.name("userName"));
		element.sendKeys("1");
		 element=driver.findElement(By.name("userPwd"));
		element.sendKeys("tom123");
		 element.submit();
	}

	@Then("^Navigate to main page$")
	public void navigate_to_main_page() throws Throwable {
	String url=driver.getCurrentUrl();
	assertTrue(url.equals("http://localhost:8084/WalletApp/validateLogin"));
	}
	@After
	public void tearDown()
	{
		driver.close();
	}
	
	
	
	
	
	
	
	@Given("^Open main page$")
	public void open_main_page() throws Throwable {
		
		driver.get("http://localhost:8084/WalletApp/validateLogin");
		//element.submit();
	   	}

	@When("^create account clicked$")
	public void create_account_clicked() throws Throwable {
		//driver.switchTo().frame("cntFrame");
	//	driver.findElement(By.partialLinkText("Click")).click();
	//	String s=driver.findElement(By.name("h1tag")).getText();
	//	System.out.println("value of s is:"+s);
		driver.findElement(By.partialLinkText("ccount")).click();
		driver.switchTo().frame("cntFrame");
	}

	@Then("^Navigate to create account page$")
	public void navigate_to_create_account_page() throws Throwable {
		/*String url=driver.getCurrentUrl();
		assertTrue(url.equals("http://localhost:8084/WalletApp/validateLogin"));*/
	}

	
	
	
	
	
	
	
	
	
	
	
	
	
}
