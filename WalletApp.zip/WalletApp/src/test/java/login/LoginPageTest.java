package login;

import static org.junit.Assert.*;
import static org.mockito.Mockito.timeout;

import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import page.LoginPageBean;

public class LoginPageTest {

private WebDriver driver;
private LoginPageBean loginPageBean;
  
  @Before
  public void setUp()
  {
		System.setProperty("webdriver.chrome.driver", "D:\\Driver\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		loginPageBean=new LoginPageBean(driver);
  }


 @Test
  public void check_loginpage_navigation()
  {
	 driver.get("http://localhost:8084/WalletApp/");
	 loginPageBean.login_to_nextpage("1","tom123");
	 
	 
  }
 
 @After
 public void tearDown()
 {
	 driver.close();
 }
}
