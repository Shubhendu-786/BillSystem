package org.cap.service;

import java.util.Date;
import java.util.List;

import org.cap.model.Account;
import org.cap.model.Transaction;

public interface AccountService {
	public void createAccount(Account account);
	public List<Account> getAllAccount(Integer id);
	public List<Account> getAccountWithBalance(int custId);
	public void createTransactionAccount(Transaction account);
	public List<Transaction> getTransactions(Integer id);
	public Account findAccount(long accountNo);
	public List<Account> getOtherAccount(Integer id);

	public List<Transaction> getDatedTransactions(Integer id,Date d1,Date d2);
}
