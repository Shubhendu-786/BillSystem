package org.cap.service;

import java.util.List;

import org.cap.model.Account;
import org.cap.model.Customer;

public interface WalletService {
	//public Customer getLogin(String uname,Integer password);
	   public List<Customer> getLogin(Integer id,String Password);
	   public String getCustomerName(Integer id);
	   public Customer findCustomer(int customerId);
	/*public void saveAccount(Account acc);
	public List<Account> getAllAccount(Integer id);
	public Account find(Integer id);
*/
}
