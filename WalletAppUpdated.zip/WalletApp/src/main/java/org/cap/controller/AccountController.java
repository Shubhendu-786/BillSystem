package org.cap.controller;

import java.util.List;

import org.cap.model.Account;
import org.cap.model.Login;
import org.cap.service.WalletService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class AccountController {
   @Autowired
   private WalletService walletService;
	@PostMapping("/validateLogin")
	public String validateLogin(ModelMap map, 
			@RequestParam("userName")String userName,
			@RequestParam("userPwd")String userPwd) {
		
		List<Login> login=walletService.getLogin(userName,userPwd);
		if(login.size()!=0)
		{
			
			return "main";
		}
		
		return "redirect:/";
	}
	
	
	
	
	
	
	
	@RequestMapping("/createAccount")
	public String showCreateAccountPage() {
		return "createAccount";
	}
	
	
	
	
	@RequestMapping("/createDone")
	public String showcreateAccountDonePage(ModelMap map,
            @RequestParam("accType") String accType,
            @RequestParam("amount") String amount) {
		Account acc=new Account();
		acc.setAccountNo("1111");
		acc.setAccType(accType);
		acc.setCustomerId(1);
		acc.setOpeningBalance(amount);
		acc.setStatus("active");
		walletService.saveAccount(acc);
		
		
		
		
		
		
		
		return "successfull";
	}
	
	
	
	
	
	
	@RequestMapping("/showBalance")
	public String showBalancePage() {
		return "showBalance";
	}
	
	@RequestMapping("/deposit")
	public String depositPage() {
		return "deposit";
	}
	
	
	
	
}
