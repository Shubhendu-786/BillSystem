package org.cap.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Account {
	@Id
	@GeneratedValue
	private int accountId;
	private String accountNo;
	private String accType;
	private String openingBalance;
	private int customerId;
	private String status;
	public int getAccountId() {
		return accountId;
	}
	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}
	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	public String getAccType() {
		return accType;
	}
	public void setAccType(String accType) {
		this.accType = accType;
	}
	public String getOpeningBalance() {
		return openingBalance;
	}
	public void setOpeningBalance(String openingBalance) {
		this.openingBalance = openingBalance;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "Account [accountId=" + accountId + ", accountNo=" + accountNo + ", accType=" + accType
				+ ", openingBalance=" + openingBalance + ", customerId=" + customerId + ", status=" + status + "]";
	}
	public Account(int accountId, String accountNo, String accType, String openingBalance, int customerId,
			String status) {
		super();
		this.accountId = accountId;
		this.accountNo = accountNo;
		this.accType = accType;
		this.openingBalance = openingBalance;
		this.customerId = customerId;
		this.status = status;
	}
	public Account() {
		
		// TODO Auto-generated constructor stub
	}

}
