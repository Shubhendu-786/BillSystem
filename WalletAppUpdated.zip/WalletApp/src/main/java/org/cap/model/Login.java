package org.cap.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Login {
@Id
@GeneratedValue
private int custId;
private String firstName;
private String lastName;
private String email;
private String mobNo;
private String password;
private String status;
private Date lastLoginDate;
public Login() {
	// TODO Auto-generated constructor stub
}
public Login(int custId, String firstName, String lastName, String email, String mobNo, String password, String status,
		Date lastLoginDate) {
	super();
	this.custId = custId;
	this.firstName = firstName;
	this.lastName = lastName;
	this.email = email;
	this.mobNo = mobNo;
	this.password = password;
	this.status = status;
	this.lastLoginDate = lastLoginDate;
}
@Override
public String toString() {
	return "Login [custId=" + custId + ", firstName=" + firstName + ", lastName=" + lastName + ", email=" + email
			+ ", mobNo=" + mobNo + ", password=" + password + ", status=" + status + ", lastLoginDate=" + lastLoginDate
			+ "]";
}
public int getCustId() {
	return custId;
}
public void setCustId(int custId) {
	this.custId = custId;
}
public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}
public String getLastName() {
	return lastName;
}
public void setLastName(String lastName) {
	this.lastName = lastName;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getMobNo() {
	return mobNo;
}
public void setMobNo(String mobNo) {
	this.mobNo = mobNo;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}
public Date getLastLoginDate() {
	return lastLoginDate;
}
public void setLastLoginDate(Date lastLoginDate) {
	this.lastLoginDate = lastLoginDate;
}
}
