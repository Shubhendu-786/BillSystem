package org.cap.service;

import java.util.List;

import org.cap.dao.WalletDao;
import org.cap.model.Account;
import org.cap.model.Login;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service("walletService")
public class WalletServiceImpl implements WalletService{
    @Autowired
    private WalletDao walletDao;
	@Override
	public List<Login> getLogin(String uname, String password) {
		// TODO Auto-generated method stub
		return walletDao.getLogin(uname, password);
	}
	@Override
	public void saveAccount(Account acc) {
		// TODO Auto-generated method stub
		walletDao.saveAccount(acc);
	}
	

}
