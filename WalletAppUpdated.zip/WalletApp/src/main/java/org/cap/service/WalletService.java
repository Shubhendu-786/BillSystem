package org.cap.service;

import java.util.List;

import org.cap.model.Account;
import org.cap.model.Login;

public interface WalletService {
	public List<Login> getLogin(String uname,String password);
	public void saveAccount(Account acc);

}
