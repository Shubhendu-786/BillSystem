package org.cap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.cap.model.Account;
import org.cap.model.Login;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
@Transactional
@Repository("walletDao")
public class WalletDaoImpl implements WalletDao{
@PersistenceContext
private EntityManager entityManager;
	@Override
	public List<Login> getLogin(String uname,String password) {
		// TODO Auto-generated method stub
		Query l= entityManager.createQuery("select l from Login l where l.firstName=:uname and password=:pass");
        l.setParameter("uname", uname);
        l.setParameter("pass", password);
		List<Login> m=l.getResultList();
        System.out.println(m);
         
         
         
		return m;
	}
	@Override
	public void saveAccount(Account acc) {
		// TODO Auto-generated method stub
		entityManager.persist(acc);
	}

}
