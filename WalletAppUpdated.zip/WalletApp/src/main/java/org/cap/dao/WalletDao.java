package org.cap.dao;

import java.util.List;

import org.cap.model.Account;
import org.cap.model.Login;

public interface WalletDao {
public List<Login> getLogin(String uname,String password);
public void saveAccount(Account acc);
}
