package org.cap.demo.model;

import java.util.Date;


public class Customer {
	
	private int customerId;
	private String customerName;
	private String phoneNumber;
	
	private String emailId;
	private Date dateOfBirth;
	private String password;
	
	


	
	public Customer(int customerId, String customerName, String phoneNumber, String emailId, Date dateOfBirth,
			String password) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.phoneNumber = phoneNumber;
		this.emailId = emailId;
		this.dateOfBirth = dateOfBirth;
		this.password = password;
	}





	public int getCustomerId() {
		return customerId;
	}





	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}





	public String getCustomerName() {
		return customerName;
	}





	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}





	public String getPhoneNumber() {
		return phoneNumber;
	}





	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}





	public String getEmailId() {
		return emailId;
	}





	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}





	public Date getDateOfBirth() {
		return dateOfBirth;
	}





	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}





	public String getPassword() {
		return password;
	}





	public void setPassword(String password) {
		this.password = password;
	}





	public Customer()
	{
		
	}
	
	
	
	
}
