package p3;
import p1.p2.B;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import p1.A;
public class C {

	public static void main(String[] args) {
		/*StringBuilder sb1=new StringBuilder("Duke");
		
		String str1=sb1.toString();
		String str2=str1;
		
		System.out.println("Result B"+1+2);
		System.out.println(str1==str2);*/
		
		/*LocalDateTime dt=LocalDateTime.of(2014, 8, 31, 1, 1);
		//dt.plusDays(5);
		dt.plusMonths(1);
		System.out.println(dt.format(DateTimeFormatter.ISO_DATE));*/
		/*
		int n[][]= {{1,3},{2,4}};
		//System.out.println(n.length);
		for(int i=n.length-1;i>=0;i--)
		{
			for(int y:n[i])
			{
				System.out.print(y);
			}
		}*/
		
		
	/*	LocalDate date1=LocalDate.now();
		LocalDate date2=LocalDate.of(2014,6,20);
		LocalDate date3=LocalDate.parse("2014/06/20");
        System.out.println("date1 "+date1);
        System.out.println("date2" + date2);
        System.out.println("date3"+ date3);*/
		
	/*	
		int wd=0;
		String days[]= {"sun","mon","wed","sat"};
		
		for(String s:days)
		{
			switch(s)
			{
			case "sat":
			case "sun":
				wd-=1;
				break;
			case"mon":
				wd++;
			case "wed":
				wd+=2;
			}
		}
		System.out.println(wd);
		*/
		
		String[] arr= {"Hi","How","Are","You"};
		List<String> arrList=new ArrayList<>(Arrays.asList(arr));
		
		if(arrList.removeIf((String s)-> {return s.length()<=2;}))
		{
		//	System.out.println(s+"removed");
		}
		
		
	}
}
