package org.sm;

public class bubble {
public static void main(String[] args) {
	int c[]= {5,4,1,2,0};
	/*for(int k=0;k<5;k++)
	System.out.println(c[k]);
	
	for(int i=0;i<5;i++)
	{
		for(int j=0;j<5-i-1;j++)
		{
			if(c[j]>c[j+1])
			{
				char temp=c[j];
				c[j]=c[j+1];
				c[j+1]=temp;
				
				}
		}
	}
	System.out.println("sorted list is");
	for(int k=0;k<5;k++)
	System.out.print(c[k]);*/
	
	
	/*for(int i=0;i<5;i++)
	{  int temp=i;
		for(int j=i+1;j<5;j++)
		{
			if(c[temp]>c[j])
			{
				temp=j;
			}
			
		}
		if(temp!=i)
		{
			 char e=c[temp];
			c[temp]=c[i];
			c[i]=e;
	
		}
	}
	System.out.println("sorted list is");
	for(int k=0;k<5;k++)
	System.out.print(c[k]);*/
	
	
	
	/*for(int i=1;i<5;i++)
	{  int temp=c[i];
	    int j=i-1;
	    System.out.println(c[i]);
		while(j>=0&&temp<c[j])
		{
	      c[j+1]=c[j];
	      j=j-1;
		}
		c[j+1]=temp;
	}

System.out.println("sorted list is");
for(int k=0;k<5;k++)
System.out.print(c[k]);*/
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
}
