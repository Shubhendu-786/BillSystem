package org.sm;

import java.util.Scanner;

public class Demo {
	 
  void receive()
  {
	   Scanner sc=new Scanner(System.in);
  }
	
}
