package org.sm;

interface I1 {
    default int doStuff() { return 1; }
  }
  interface I2 {
    default int doStuff() { return 2; }
  }
  public class MultiInt implements I1, I2 {  // needs to override
    public static void main(String[] args) {
      new MultiInt().go();
      
     float f=99;
     int i=(int)f;
    }
    void go() {
    
    System.out.println(doStuff());
    return;
  }
	@Override
	public int doStuff() {
		// TODO Auto-generated method stub
		return I2.super.doStuff();
	}
    
	
	
/*	@Override
	public int doStuff() {
		// TODO Auto-generated method stub
		return I1.super.doStuff();
	}
*/   }
  