package org.sm;

class Demo1
{ Demo1(int a)
	{
	System.out.println("I am in demo");
	}

   Demo1()
   {
	    System.out.println("i am in demo1");
   }
}

public class ConsDemo extends Demo1{
	ConsDemo()
	{
		System.out.println("I am in ConsDemo");
	}
	
	ConsDemo(float a,float b)
	{
		System.out.println(a+","+b);
	}
	
	ConsDemo(int a,int b)
	{this(2.0f,3f);
		System.out.println(a+","+b);
	}
	
	public static void main(String[] args) {
		ConsDemo d=new ConsDemo(2,3);
	}
}
