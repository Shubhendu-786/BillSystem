package org.sm;

public class App {
public static void main(String[] args) {
	String str1="Java";
	String str2=new String("java");
	String str3=str2;
	
}
}
