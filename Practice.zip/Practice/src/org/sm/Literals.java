package org.sm;

import java.sql.Date;

public class Literals {
	
	Object o;
	
	int show()
	{
		 System.out.println("arr is"+o);
		return 0;
	}
	String show1()
	{
		return "show";
	}
	
public static void main(String[] args) {
	int b=133;
	System.out.println(b);
	byte b1=(byte)130;
	
	byte s=3;
	b1-=89;
	System.out.println(s);
	
	System.out.println(b1);
	
	/*int a[];
	System.out.println(a);*/
	
	Integer i=new Integer(42);
	//Integer i2=42;
	Integer i1=new Integer(42);
	System.out.println(i==i1);
	
	new Literals().show();
}
}
