package org.sm;
class Sam
{
	 void show()
	 {
		  System.out.println("I am in sam show");
	 }
}
public class Inherit extends Sam{
	void show()
	{
		 System.out.println("I am in inherit show");
	}
public static void main(String[] args) {
	Sam s=new Inherit();
	s.show();
}
}
