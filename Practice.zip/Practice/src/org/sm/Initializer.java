package org.sm;
class Sam2
{
	Sam2()
	{
		System.out.println("i am in sam constructer");
	}
}
public class Initializer extends Sam2{

	static
	{
		System.out.println("static method called");
	}
	{System.out.println("second init called");}
	{System.out.println("first init called");}
	
	
	Initializer()
	{
		System.out.println("constructer called");
		{System.out.println("Third init called");}
	}
	
	public static void main(String[] args) {
		Initializer i=new Initializer();
		Initializer i1=new Initializer();
		{System.out.println("Third init called");}
	}
	
}
