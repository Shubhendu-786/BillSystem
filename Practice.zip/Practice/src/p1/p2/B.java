package p1.p2;
import p1.A;
public class B {
public void doStuff()
{
	A b=new A();
}
}
