function validate1()
{
	
var fname1=myform.fname.value;
var lname1=myform.lname.value;
var address1=myform.address.value;
var mobno1=myform.mobileNo.value;


var city1=myform.city.value;




/*var city1 = document.getElementById("city3").value;
//var city1 = city2.options[city2.selectedIndex].value;
*/


var state1=myform.state.value;
var gender1=myform.gender.value;
var course1=myform.course.value;
var letters=/^[A-Za-z]+$/;
var mobno="[1-9]{1}[0-9]{9}";
var flag=false;
if(fname1.length>0)
	{
	  if(fname1.match(letters))
	     {
		  document.getElementById("errFname").innerHTML="";
		  flag=true;}
	  else
		  {
	 // document.getElementById("errFname").innerHTML="Enter valid name";
		  alert("Enter valid name");
	//  flag=true;
		  }
	}
  
else
	{
	//document.getElementById("errFname").innerHTML="Name Should not be Empty";
	 alert("name should not be empty");
	}






if(lname1.length!="")
{
  if(lname1.match(letters))
     {document.getElementById("errlname").innerHTML="";
	 if(flag)
     flag=true;}
  else
	  {
 // document.getElementById("errlname").innerHTML="Enter valid name";
	  alert("Enter valid last name");
    flag=false;
	  }
}

else
{
//document.getElementById("errlname").innerHTML="Name Should not be Empty";
	  alert("Enter valid last name");

flag=false;
}



if(address1=="")
	{
	document.getElementById("erraddress").innerHTML="Enter valid address";
	flag=false;
	}

else
	 {
	document.getElementById("erraddress").innerHTML="";
	 
	 }



  if(city1=="")
	  {
	  document.getElementById("errcity").innerHTML="Choose a city";
	  }
  else
	  {
	  document.getElementById("errcity").innerHTML="";
	  if(flag)
	  flag=true;
	  }

  if(state1=="")
  {
  document.getElementById("errstate").innerHTML="Choose a state";
  }
else
  {
  document.getElementById("errstate").innerHTML="";
  if(flag)
  flag=true;
  }

  if(gender1=="")
  {
  document.getElementById("errgender").innerHTML="Choose a gender";
  }
else
  {
  document.getElementById("errgender").innerHTML="";
  if(flag)
	  {
  flag=true;}
  }
  if(course1=="")
  {
  document.getElementById("errcourse").innerHTML="Choose a course";
  }
else
  {
  document.getElementById("errcourse").innerHTML="";
  if(flag)
  flag=true;
  }
  
if(mobno1=="")
{
document.getElementById("errmobile").innerHTML="Enter valid Mobile Number";
flag=false;
}

else
 {
	if(mobno1.length==10)
	  {
		 if(mobno1.match(mobno))
			 { document.getElementById("errmobile").innerHTML="";
			  if(flag==true)
			  flag=true;
			  else
				  flag=false;
			 }
		 else
			 {
			 document.getElementById("errmobile").innerHTML="Enter valid nobile no";
			  flag=false;
			 }
	  }
	else
     {document.getElementById("errmobile").innerHTML="Mobile no should be of 10 digit";
      flag=false;
     } }


  

if(flag)
	 {
	 alert("You are successfully registerd");
	 }




  return flag;



}



function validate3()
{
	
 var name=form.cardHolderName.value;
 var cardNumber=form.cardNumber.value;
 var cvv=form.cvv.value;
 //var date=document.getElementById("mydate");
 
 //var date = new Date($('#mydate').val());
 var date=form.expiryDate.value;
 var letters=/^[A-Za-z]+$/;
 var cardno="[0-9]{1}[0-9]{15}";
 var cvvno="[0-9]{3}";
 //var today=new Date();

 var today = new Date();
 var dd = today.getDate();
 
 var mm = today.getMonth()+1;//January is 0!
 var mm1="0"+mm;
 var yyyy = today.getFullYear();
 var today = yyyy+'-'+mm1+'-'+"0"+dd;
 
 if(name.length>0)
	{
	  if(name.match(letters))
	     {
		  document.getElementById("errname").innerHTML="";
		  flag=true;}
	  else
		  {
	  document.getElementById("errname").innerHTML="Enter valid name";
	//  flag=true;
		  }
	}

else
	{
	document.getElementById("errname").innerHTML="Name Should not be Empty";
	
	}

 
 
 if(cardNumber=="")
 {
 document.getElementById("errcard").innerHTML="Enter valid card Number";
 flag=false;
 }

 else
  {
 	if(cardNumber.length==16)
 	  {
 		 if(cardNumber.match(cardno))
 			 { document.getElementById("errcard").innerHTML="";
 			
 			  flag=true;
 			  
 			 }
 		 else
 			 {
 			 document.getElementById("errcard").innerHTML="Enter valid card no";
 			  flag=false;
 			 }
 	  }
 	else
      {document.getElementById("errcard").innerHTML="Card no should be of 16 digit";
       flag=false;
      } }




 if(cvv=="")
 {
 document.getElementById("errcvv").innerHTML="Enter valid cvv Number";
 flag=false;
 }

 else
  {
 	if(cvv.length==3)
 	  {
 		 if(cvv.match(cvvno))
 			 { document.getElementById("errcvv").innerHTML="";
 			 if(flag)
 			  flag=true;
 			  
 			 }
 		 else
 			 {
 			 document.getElementById("errcvv").innerHTML="Enter valid cvv no";
 			  flag=false;
 			 }
 	  }
 	else
      {document.getElementById("errcvv").innerHTML="Cvv no should be of 3 digit";
       flag=false;
      } }


  if(date<"2018-08-03"||date=="")
	  {
	  document.getElementById("errdate").innerHTML="Enter valid expiry date";
      flag=false;
      alert(date);
	  }
  else
	  {

	  document.getElementById("errdate").innerHTML="";
	//  alert(today);
	  if(flag)
      flag=true;
	  
	  }
  
  if(flag)
	  {
	  alert("Your payment Complemented Successfully");
	  }
  return flag;

}


