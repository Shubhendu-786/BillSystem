package register;

import static org.junit.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import page.LocalPageBean;
import page.LocalPageBean1;

public class Stepdef {
	private WebDriver driver;
	private LocalPageBean localPageBean;
	private LocalPageBean1 localPageBean1;
	@Before
	public void setUp()
	{
		System.setProperty("webdriver.chrome.driver", "D:\\Driver\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		localPageBean=new LocalPageBean(driver);
		localPageBean1=new LocalPageBean1(driver);
	}
	
	
	@Given("^Customer Details$")
	public void customer_Details() throws Throwable {
	 driver.get("http://localhost:8089/Day3-stuRegistration/");
	}

	@When("^Details are valid$")
	public void details_are_valid() throws Throwable {
	  localPageBean.login_to_paymentpage("shubhendu", "mal", "Krishna colony","pune","mumbai","male","btech","6786786786");
	}

	@Then("^navigate to payment page$")
	public void navigate_to_payment_page() throws Throwable {
	      driver.switchTo().alert();
	     // driver.get("http://localhost:8088/Day3-stuRegistration/PersonalDetails.html");
	}

	@Given("^paymentDetails page$")
	public void paymentdetails_page() throws Throwable {
	      driver.get("http://localhost:8089/Day3-stuRegistration/PersonalDetails.html");
		//driver.switchTo().alert().accept();
	}

	@When("^details are valid$")
	public void details_are_valid1() throws Throwable {
	    localPageBean1.navigate_again("satish","1234123412341234", "123", "2017-01-01");
	}

	@Then("^get the message of successfull registration$")
	public void get_the_message_of_successfull_registration() throws Throwable {
	 String s=driver.switchTo().alert().getText();
	 assertEquals(s, "Your payment Complemented Successfully");
	}
	
	
	
	@Given("^Customer Registration page$")
	public void customer_Registration_page() throws Throwable {
		 driver.get("http://localhost:8089/Day3-stuRegistration/");
	}

	@Given("^Customer details$")
	public void customer_details() throws Throwable {
	  localPageBean.login_to_paymentpage("", "satya", "ramnagar", "mumbai", "pune", "male", "llb", "3453453451");
	}

	@When("^click on submit button$")
	public void click_on_submit_button() throws Throwable {
	
	}

	@Then("^get the alert box with message 'Invalid second name'$")
	public void get_the_alert_box_with_message_Invalid_second_name() throws Throwable {
	 String s= driver.switchTo().alert().getText();
	 assertEquals(s, "name should not be empty");
	}
	
	
	
	
	
	
	
	
	
	
	
}
