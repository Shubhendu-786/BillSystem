package page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LocalPageBean1 {
   WebDriver driver;
   
    @FindBy(name="cardHolderName")
    private WebElement cardHolder;

    
    @FindBy(name="cardNumber")
    private WebElement cardNo;
    
    
    @FindBy(name="cvv")
    private WebElement cvv;
    
    @FindBy(name="expiryDate")
    private WebElement date;

    @FindBy(name="click1")
    private WebElement subLogin;
    
    public LocalPageBean1(WebDriver driver)
    {
    	this.driver=driver;
    	PageFactory.initElements(driver, this);
    }
    
    public void setCardHolder(String holder)
    {
    	cardHolder.sendKeys(holder);
    }
    public void setCardNumber(String number)
    {
    	cardNo.sendKeys(number);
    }
    public void setCvv(String cv)
    {
    	cvv.sendKeys(cv);
    }
    public void setExpiryDate(String date1)
    {
    	date.sendKeys(date1);
    }
    public void setLogin()
    {
    	subLogin.click();
    }
    public void navigate_again(String name,String no,String cv,String date2)
    {
    	this.setCardHolder(name);
    	this.setCardNumber(no);
    	this.setCvv(cv);
    	this.setExpiryDate(date2);
    	this.setLogin();
    }
    
}
