package page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LocalPageBean {

	
	WebDriver driver;
	@FindBy(name="fname")
	private WebElement firstName;
	
	@FindBy(name="lname")
	private WebElement lastName;
	
	@FindBy(name="address")
	private WebElement address;
	
	@FindBy(name="city")
	private WebElement city;
	@FindBy(name="state")
	private WebElement state;
	@FindBy(name="gender")
	private WebElement gender;
	@FindBy(name="course")
	private WebElement course;
	@FindBy(name="mobileNo")
	private WebElement mobno;
	
	@FindBy(name="click")
	private WebElement subLogin;
	
	
	public LocalPageBean(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	
	public void setFirst(String fname)
	{
		firstName.sendKeys(fname);
	}
	public void setLast(String lname)
	{
		lastName.sendKeys(lname);
	}
	public void setAddress(String add)
	{
		address.sendKeys(add);
	}
	public void setCity(String c)
	{
		city.sendKeys(c);
	}
	public void setState(String s)
	{
		state.sendKeys(s);
	}
	public void setGender(String g)
	{
		gender.click();
		
		//gender.sendKeys(g);
	}
	public void setCourse(String c)
	{
		course.sendKeys(c);
	}
	public void setMobile(String mobile)
	{
		mobno.sendKeys(mobile);
	}
	 public void setSubLogin() {
			//	driver.findElement(subLogin).submit();
				subLogin.click();
			}
	
	public void login_to_paymentpage(String fname,String lname,String address,String city,String state,String gender,String course,String mobno) {
		this.setFirst(fname);
		this.setLast(lname);
		this.setAddress(address);
		this.setCity(city);
		this.setState(state);
		this.setGender(gender);
		this.setCourse(course);
		this.setMobile(mobno);
		this.setSubLogin();
		
	}
	
	
	
}
