package com.capgemini.PilotApp.controller;

import java.util.HashMap;
import java.util.List;
import javax.validation.Valid;
import com.capgemini.PilotApp.model.Pilot;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MyController {
	
	
	//private Pilot pilot;


	@RequestMapping("/pilotForm")
	public String getPilotForm(ModelMap map) {
		//List<Pilot> pilots= pilotService.getAll();
		
		final String uri="http://localhost:8091/PilotRestApp/api/v1/pilots";
		RestTemplate restTemplate=new RestTemplate();
		
		Pilot[] pilots= restTemplate.getForObject(uri, Pilot[].class);
		
		
		map.put("pilots",pilots);
		map.put("pilot", new Pilot());
		
		return "pilotForm";
	}
	
		
	@PostMapping("/savePilot")
	public String showPilotDetails(
			@Valid @ModelAttribute("pilot") Pilot pilot,
			BindingResult result) {
		if(!result.hasErrors()) {
			
			final String uri="http://localhost:8091/PilotRestApp/api/v1/pilots";
			RestTemplate restTemplate=new RestTemplate();
			
		//	ResponseEntity<Pilot> pilot1=
					restTemplate.postForEntity(uri,pilot,Pilot.class);
		
		}
		
		return "redirect:pilotForm";
	}
		
	/*@RequestMapping("/pilotForm")
	public String getPilot(ModelMap map) {
		List<Pilot> pilots= pilotDBService.getAllPilots();
		
		map.put("pilots",pilots);
		if(pilot!=null)
			map.put("pilot", pilot);
		else
		map.put("pilot", new Pilot());
		
		return "pilotForm";
		
	}
*/
	@GetMapping("/delete/{pilotId}")
	public String deletePilot(@PathVariable("pilotId") Integer pilotId) {
		
		final String uri="http://localhost:8091/PilotRestApp/api/v1/pilots//{pilotId}";
		RestTemplate restTemplate=new RestTemplate();
		
		
		java.util.Map<String, Object> params=new HashMap<>();
		params.put("pilotId", pilotId);
		
		restTemplate.delete(uri,params);
		return "redirect:/pilotForm";
	}
	
	/*
	@GetMapping("/delete/{pilotId}")
	public String updatePilot(@PathVariable("pilotId") Integer pilotId) {
		
		final String uri="http://localhost:8091/PilotRestApp/api/v1/pilots//{pilotId}";
		RestTemplate restTemplate=new RestTemplate();
		
		
		java.util.Map<String, Object> params=new HashMap<>();
		params.put("pilotId", pilotId);
		
		restTemplate.delete(uri,params);
		return "redirect:/pilotForm";
	}
	*/
	
	
	/*@RequestMapping("/updatePilot")
	public String updatePilot(@ModelAttribute("pilot")Pilot pilot1) {
		
		if(pilot1!=null) {
			
			pilotDBService.updatePilot(pilot1);
			pilot=null;
		}
		return "redirect:/pilotForm";
	}
	*/
	@RequestMapping("/edit/{pilotId}")
	public String findPilot(@PathVariable("pilotId") Integer pilotId,ModelMap map) {
		final String uri="http://localhost:8091/PilotRestApp/api/v1/pilots";
		RestTemplate restTemplate=new RestTemplate();
		
		Pilot[] pilots= restTemplate.getForObject(uri, Pilot[].class);
//		System.out.println("pilots are available");
		
		map.put("pilots",pilots);
		//map.put("pilot", new Pilot());

		
		final String uri1="http://localhost:8091/PilotRestApp/api/v1/pilot/{pilotId}";

		java.util.Map<String, Object> params=new HashMap<>();
		params.put("pilotId", pilotId);
		ResponseEntity<Pilot> pilot=restTemplate.getForEntity(uri1, Pilot.class,params);
		System.out.println("in front end"+pilot);
		if(pilot!=null)
			map.put("pilot",pilot);
		else
			map.put("pilot", new Pilot());
		//restTemplate.putFor
	
		return "redirect:/pilotForm";
	}
}
 


