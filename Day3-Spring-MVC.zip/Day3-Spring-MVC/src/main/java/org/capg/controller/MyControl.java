package org.capg.controller;

import java.util.List;

import javax.validation.Valid;

import org.capg.model.Pilot;
import org.capg.service.PilotService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MyControl {
	
	@Autowired
	private PilotService pilotService;
	
	@RequestMapping("/hi")
	public ModelAndView sayHello()
    {
	    String message="Hello World";
	    return new ModelAndView("helloPage","msg",message);
	    
     }
	 
	@RequestMapping("/validateLogin")
	public String validatLogin(ModelMap map,
			                   @RequestParam("username") String username,
	                           @RequestParam("userPwd") String userPwd)
	{
		if(username.equals("tom")&& userPwd.equals("tom123"))
		{
			List<Pilot> pilots=pilotService.getAll();
			map.put("pilots", pilots);
			map.put("pilot", new Pilot());
			
			return "pilotForm";
		}
		
		return "redirect:/";
	}
	

	@RequestMapping("/pilotForm")
	public String getPilotForm(ModelMap map) {
		List<Pilot> pilots= pilotService.getAll();
		
		map.put("pilots",pilots);
		map.put("pilot", new Pilot());
		
		return "pilotForm";
	}
	
	
	
	/*@RequestMapping("/pilotForm1")
	public String getPilotForm1(ModelMap map) {
		List<Pilot> pilots= pilotService.getAll();
		
		map.put("pilots",pilots);
		map.put("pilot", new Pilot());
		
		return "pilotForm";
	}*/
	
	
	
	//@RequestMapping(value="/savePilot",method=RequestMethod.POST)
	@GetMapping("/savePilot")
	public String showPilotDetails(@Valid @ModelAttribute("pilot") Pilot pilot,BindingResult result)
	{if(!result.hasErrors())
	{
		pilotService.save(pilot);
		System.out.println(pilot);
		//return "showPilot";
	}
	  return "redirect:pilotForm";
	}
	
	@GetMapping("/delete/{pilotId}")
	public String deleteDetails(@PathVariable("pilotId") Integer pilotId)
	{
       pilotService.delete(pilotId);
		
		return "redirect:/pilotForm";
	}
	@GetMapping("/edit/{pilotId}")
	public String edit(@PathVariable("pilotId") Integer pilotId,ModelMap map)
	{
		Pilot pilot=pilotService.find(pilotId);
		//map.put("pilot1", pilot);
		System.out.println(pilot);
	List<Pilot> pilots= pilotService.getAll();
		
		map.put("pilots",pilots);
		
		map.put("pilot",pilot);
		return "pilotForm";
	}
}
	
	
	

