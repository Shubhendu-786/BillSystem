package org.capg.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;

import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;
@Entity
public class Pilot {
//@NotNull(message="* Id should not be empty")
//@Min(value=35,message=" * Enter id >=35")
@Id
@GeneratedValue
private int pilotId;
//@NotEmpty(message="* FirstName should not be null")
private String firstName;
private String lastName;
//@Past(message=" * Enter Past Date")
private Date dateOfBirth;
private Date dateOfJoining;
private Boolean isCertified;
//@Range(min=1000,max=100000,message="Enter range Between 1000 and 1lac")
private double salary;

public int getPilotId() {
	return pilotId;
}
public void setPilotId(int pilotId) {
	this.pilotId = pilotId;
}
public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}
public String getLastName() {
	return lastName;
}
public void setLastName(String lastName) {
	this.lastName = lastName;
}


public Date getDateOfBirth() {
	return dateOfBirth;
}
public void setDateOfBirth(Date dateOfBirth) {
	this.dateOfBirth = dateOfBirth;
}
public Date getDateOfJoining() {
	return dateOfJoining;
}
public void setDateOfJoining(Date dateOfJoining) {
	this.dateOfJoining = dateOfJoining;
}
public Boolean getIsCertified() {
	return isCertified;
}
public void setIsCertified(Boolean isCertified) {
	this.isCertified = isCertified;
}
public double getSalary() {
	return salary;
}
public void setSalary(double salary) {
	this.salary = salary;
}
@Override
public String toString() {
	return "Pilot [pilotId=" + pilotId + ", firstName=" + firstName + ", LastName=" + lastName + ", dateOfBirth="
			+ dateOfBirth + ", dateOfJoining=" + dateOfJoining + ", isCertified=" + isCertified + ", salary=" + salary
			+ "]";
}
public Pilot()
{
	
}
public Pilot(int pilotId, String firstName, String lastName, Date dateOfBirth, Date dateOfJoining, Boolean isCertified,
		double salary) {
	super();
	this.pilotId = pilotId;
	this.firstName = firstName;
	this.lastName = lastName;
	this.dateOfBirth = dateOfBirth;
	this.dateOfJoining = dateOfJoining;
	this.isCertified = isCertified;
	this.salary = salary;
}


}
