package org.capg.service;

import java.util.List;

import org.capg.dao.PilotDao;
import org.capg.model.Pilot;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service("pilotService")
public class PilotServiceImpl implements PilotService{

	@Autowired
	private PilotDao pilotDao;
	
	@Override
	public void save(Pilot pilot) {
		// TODO Auto-generated method stub
		pilotDao.save(pilot);
	}

	@Override
	public List<Pilot> getAll() {
		// TODO Auto-generated method stub
		return pilotDao.getAll();
	}

	@Override
	public void delete(Integer pilotId) {
		// TODO Auto-generated method stub
		 pilotDao.delete(pilotId);
	}

	@Override
	public Pilot find(Integer pilotId) {
		// TODO Auto-generated method stub
		return pilotDao.find(pilotId);
	}

}
