package org.capg.service;

import java.util.List;

import org.capg.model.Pilot;
import org.springframework.stereotype.Service;
@Service
public interface PilotService {
public void save(Pilot pilot);
public List<Pilot> getAll();
public void delete(Integer pilotId);
public Pilot find(Integer pilotId);


}
