package org.capg.dao;

import java.util.List;

import org.capg.model.Pilot;

public interface PilotDao {
public void save(Pilot pilot);
public List<Pilot> getAll();
public void delete(Integer pilotId);
//public void edit(Integer pilotId);
public Pilot find(Integer pilotId);

}
