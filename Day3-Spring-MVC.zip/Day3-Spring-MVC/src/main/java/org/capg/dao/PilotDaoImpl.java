package org.capg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
//import javax.transaction.Transactional;
import javax.transaction.Transactional;

import org.capg.model.Pilot;
import org.springframework.stereotype.Repository;
//import org.springframework.transaction.annotation.Transactional;
//@Transactional
@Repository("pilotDao")
public class PilotDaoImpl implements PilotDao{
   @PersistenceContext
   private EntityManager entityManager;
	@Transactional
   @Override
	public void save(Pilot pilot) {
		// TODO Auto-generated method stub
		entityManager.persist(pilot);
		
	}
	@org.springframework.transaction.annotation.Transactional(readOnly=true)
	@Override
	public List<Pilot> getAll() {
		// TODO Auto-generated method stub
		List<Pilot> pilots=entityManager.createQuery("from Pilot").getResultList();
		return pilots;
	}
	@Transactional
	@Override
	public void delete(Integer pilotId) {
		// TODO Auto-generated method stub
		Pilot pilot=entityManager.find(Pilot.class, pilotId);
		entityManager.remove(pilot);
	}
	@Transactional
	@Override
	public Pilot find(Integer pilotId)
	{
		Pilot pilot=entityManager.find(Pilot.class, pilotId);
		return pilot;
	}

}
