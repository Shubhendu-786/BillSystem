package org.capg.config;

import javax.persistence.Persistence;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.LocalEntityManagerFactoryBean;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.view.InternalResourceViewResolver;
import org.springframework.web.servlet.view.JstlView;

@Configuration
@EnableWebMvc
@ComponentScan({"org.capg"})
@EnableTransactionManagement
public class AppConfigure implements WebMvcConfigurer{
@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
		// TODO Auto-generated method stub
		registry.addResourceHandler("/resources/**").addResourceLocations("/resources/");
	}
@Bean
 public InternalResourceViewResolver getResourceRevolver()
 {
	InternalResourceViewResolver viewResolver=new InternalResourceViewResolver();
	
	viewResolver.setViewClass(JstlView.class);
	viewResolver.setPrefix("/WEB-INF/view/");
	viewResolver.setSuffix(".jsp");
	return viewResolver;
 }
@Bean
 public LocalEntityManagerFactoryBean getEnityManagerFactoryBean()
 {LocalEntityManagerFactoryBean context=new LocalEntityManagerFactoryBean();
 context.setPersistenceUnitName("jpademo");
 return context;
	 
 }
@Bean
public JpaTransactionManager getJpaTransactionManager()
{
	JpaTransactionManager transactioManager=new JpaTransactionManager();
	transactioManager.setEntityManagerFactory(getEnityManagerFactoryBean().getObject());
	return transactioManager;
	
}

}
