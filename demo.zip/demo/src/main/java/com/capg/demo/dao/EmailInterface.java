package com.capg.demo.dao;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capg.demo.model.Email;

@Repository("emailDBdao")
@Transactional
public interface EmailInterface extends JpaRepository<Email, Integer>{

}
